def main():
    print('Hallo')

if __name__ == '__main__':
    main()
